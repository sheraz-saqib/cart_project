<?php
include('includes/conn.php');
error_reporting(0);
$product_id = $_POST['product_id'];
$user_id = $_POST['user_id'];
$quantity = $_POST['pro_quantity'];


function message($message){
    echo '<div class="d-inline-flex p-2">
                <p class="m-0">'.$message.'</p>
            </div>';
}



$check_sqlQ = "SELECT * FROM orders WHERE `pro_id` = $product_id AND `user_id` = $user_id";

$check_sql = mysqli_query($con, $check_sqlQ);

if(mysqli_num_rows($check_sql) > 0){
    message('some order already send request!');
    
}
else{
    $sql = "INSERT INTO `orders`(`pro_id`, `user_id`, `quantity`, `view_order`) VALUES ($product_id,$user_id,'$quantity',1)";

    $runSql = mysqli_query($con, $sql);

    if (!$runSql) {
        message('your order not place');
    }else{
        message('your order has been place');
    }
}



?>