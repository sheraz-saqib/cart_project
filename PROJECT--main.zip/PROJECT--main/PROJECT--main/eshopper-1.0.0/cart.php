<?php include('includes/conn.php'); ?>

<?php

$check_user_products = mysqli_query($con, "SELECT * FROM temp_products WHERE session_id = '$session_id' ");
$count_user_products = mysqli_num_rows($check_user_products);

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <title>EShopper - Bootstrap Shop Template</title>
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <meta content="Free HTML Templates" name="keywords">
    <meta content="Free HTML Templates" name="description">

    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">

    <!-- Font Awesome -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">

    <!-- Customized Bootstrap Stylesheet -->
    <link href="css/style.css" rel="stylesheet">
</head>

<body>
    <!-- Topbar Start -->
    <?php include('includes/topnav.php'); ?>
    <!-- Topbar End -->


    <!-- Navbar Start -->
    <?php include('includes/navbar.php'); ?>
    <!-- Navbar End -->


    <!-- Page Header Start -->
    <div class="container-fluid bg-secondary mb-5">
        <div class="d-flex flex-column align-items-center justify-content-center" style="min-height: 300px">
            <h1 class="font-weight-semi-bold text-uppercase mb-3">Shopping Cart</h1>
            <div class="d-inline-flex">
                <p class="m-0"><a href="">Home</a></p>
                <p class="m-0 px-2">-</p>
                <p class="m-0">Shopping Cart</p>
            </div>
        </div>
    </div>
    <!-- Page Header End -->
    <div class="container-fluid bg-secondary mb-5">
        <div class="d-flex flex-column align-items-center justify-content-center cart_message">

            
        </div>
    </div>

    <!-- Cart Start -->




    <div class="container-fluid pt-5">
        <div class="row px-xl-5">
            <div class="col-lg-8 table-responsive mb-5">
                <?php if ($count_user_products > 0) { ?>
                    <table class="table table-bordered text-center mb-0">
                        <thead class="bg-secondary text-dark">
                            <tr>
                                <th>Products</th>
                                <th>Price</th>
                                <th>Quantity</th>
                                <th>Total</th>
                                <th>Remove</th>
                            </tr>
                        </thead>
                        <tbody class="align-middle">

                            <?php
                            $sql = "SELECT * FROM `product`";
                            $check_user_products = mysqli_query($con, $sql);

                            if (mysqli_num_rows($check_user_products) > 0) {
                                while ($fetch_products = mysqli_fetch_array($check_user_products)) {
                                    echo '<form action="" method="POST" class="cart_form">
                                            <input name="product_id"  type="text" value="' . $fetch_products["id"] . '" hidden>
                                            <input name="user_id" type="text" value="1" hidden> 
                                        ';
                            ?>
                                    <tr>

                                        <td class="align-middle"><img src="../../NiceAdmin (1)/NiceAdmin/images/<?php echo $fetch_products['pro_images']; ?>" alt="" style="width: 50px;"><?php echo $fetch_products['pro_name']; ?></td>
                                        <td class="align-middle product_price"><?php echo $fetch_products['pro_price']; ?></td>
                                        <td class="align-middle">
                                            <div class="input-group quantity mx-auto" style="width: 100px;">
                                                <div class="input-group-btn">
                                                    <button class="btn btn-sm btn-primary btn-minus">
                                                        <i class="fa fa-minus"></i>
                                                    </button>
                                                </div>
                                                <input type="text" class="form-control form-control-sm bg-secondary text-center product_quantity" value="1" name="pro_quantity">
                                                <div class="input-group-btn">
                                                    <button class="btn btn-sm btn-primary btn-plus">
                                                        <i class="fa fa-plus"></i>
                                                    </button>
                                                </div>
                                            </div>

                                        </td>
                                        <td class="align-middle " style="width: 13rem;"><input readonly type="text" class="product_total form-control form-control-sm bg-secondary text-center " value="<?= $fetch_products['pro_price'] ?>" name="quantity"></td>
                                        <td class="align-middle"><button class="btn btn-sm btn-primary"><i class="fa fa-times"></i></button></td>
                                    </tr>
                                    </form>
                            <?php
                                }
                            } else {
                                echo "<tr><td colspan='5'>No products found</td></tr>";
                            }
                            ?>
                        </tbody>
                    </table>
                <?php } else {
                    echo "<p>No user products found</p>";
                } ?>
            </div>

            <div class="col-lg-4">
                <form class="mb-5" action="">
                    <div class="input-group">
                        <input type="text" class="form-control p-4" placeholder="Coupon Code">
                        <div class="input-group-append">
                            <button class="btn btn-primary">Apply Coupon</button>
                        </div>
                    </div>
                </form>
                <div class="card border-secondary mb-5">
                    <div class="card-header bg-secondary border-0">
                        <h4 class="font-weight-semi-bold m-0">Cart Summary</h4>
                    </div>
                    <div class="card-body">
                        <div class="d-flex justify-content-between mb-3 pt-1">
                            <h6 class="font-weight-medium">Subtotal</h6>
                            <h6 class="font-weight-medium subtotal">0</h6>
                        </div>
                        <div class="d-flex justify-content-between">
                            <h6 class="font-weight-medium">Shipping</h6>
                            <h6 class="font-weight-medium">$10</h6>
                        </div>
                    </div>
                    <div class="card-footer border-secondary bg-transparent">
                        <div class="d-flex justify-content-between mt-2">
                            <h5 class="font-weight-bold">Total</h5>
                            <h5 class="font-weight-bold last_total">0</h5>
                        </div>
                        <button class="btn btn-block btn-primary my-3 py-3 submit_cart_form">Proceed To Checkout</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- Cart End -->


    <!-- Footer Start -->
    <div class="container-fluid bg-secondary text-dark mt-5 pt-5">
        <div class="row px-xl-5 pt-5">
            <div class="col-lg-4 col-md-12 mb-5 pr-3 pr-xl-5">
                <a href="" class="text-decoration-none">
                    <h1 class="mb-4 display-5 font-weight-semi-bold"><span class="text-primary font-weight-bold border border-white px-3 mr-1">E</span>Shopper</h1>
                </a>
                <p>Dolore erat dolor sit lorem vero amet. Sed sit lorem magna, ipsum no sit erat lorem et magna ipsum dolore amet erat.</p>
                <p class="mb-2"><i class="fa fa-map-marker-alt text-primary mr-3"></i>123 Street, New York, USA</p>
                <p class="mb-2"><i class="fa fa-envelope text-primary mr-3"></i>info@example.com</p>
                <p class="mb-0"><i class="fa fa-phone-alt text-primary mr-3"></i>+012 345 67890</p>
            </div>
            <div class="col-lg-8 col-md-12">
                <div class="row">
                    <div class="col-md-4 mb-5">
                        <h5 class="font-weight-bold text-dark mb-4">Quick Links</h5>
                        <div class="d-flex flex-column justify-content-start">
                            <a class="text-dark mb-2" href="index.html"><i class="fa fa-angle-right mr-2"></i>Home</a>
                            <a class="text-dark mb-2" href="shop.html"><i class="fa fa-angle-right mr-2"></i>Our Shop</a>
                            <a class="text-dark mb-2" href="detail.html"><i class="fa fa-angle-right mr-2"></i>Shop Detail</a>
                            <a class="text-dark mb-2" href="cart.html"><i class="fa fa-angle-right mr-2"></i>Shopping Cart</a>
                            <a class="text-dark mb-2" href="checkout.html"><i class="fa fa-angle-right mr-2"></i>Checkout</a>
                            <a class="text-dark" href="contact.html"><i class="fa fa-angle-right mr-2"></i>Contact Us</a>
                        </div>
                    </div>
                    <div class="col-md-4 mb-5">
                        <h5 class="font-weight-bold text-dark mb-4">Quick Links</h5>
                        <div class="d-flex flex-column justify-content-start">
                            <a class="text-dark mb-2" href="index.html"><i class="fa fa-angle-right mr-2"></i>Home</a>
                            <a class="text-dark mb-2" href="shop.html"><i class="fa fa-angle-right mr-2"></i>Our Shop</a>
                            <a class="text-dark mb-2" href="detail.html"><i class="fa fa-angle-right mr-2"></i>Shop Detail</a>
                            <a class="text-dark mb-2" href="cart.html"><i class="fa fa-angle-right mr-2"></i>Shopping Cart</a>
                            <a class="text-dark mb-2" href="checkout.html"><i class="fa fa-angle-right mr-2"></i>Checkout</a>
                            <a class="text-dark" href="contact.html"><i class="fa fa-angle-right mr-2"></i>Contact Us</a>
                        </div>
                    </div>
                    <div class="col-md-4 mb-5">
                        <h5 class="font-weight-bold text-dark mb-4">Newsletter</h5>
                        <form action="">
                            <div class="form-group">
                                <input type="text" class="form-control border-0 py-4" placeholder="Your Name" required="required" />
                            </div>
                            <div class="form-group">
                                <input type="email" class="form-control border-0 py-4" placeholder="Your Email" required="required" />
                            </div>
                            <div>
                                <button class="btn btn-primary btn-block border-0 py-3" type="submit">Subscribe Now</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <div class="row border-top border-light mx-xl-5 py-4">
            <div class="col-md-6 px-xl-0">
                <p class="mb-md-0 text-center text-md-left text-dark">
                    &copy; <a class="text-dark font-weight-semi-bold" href="#">Your Site Name</a>. All Rights Reserved. Designed
                    by
                    <a class="text-dark font-weight-semi-bold" href="https://htmlcodex.com">HTML Codex</a><br>
                    Distributed By <a href="https://themewagon.com" target="_blank">ThemeWagon</a>
                </p>
            </div>
            <div class="col-md-6 px-xl-0 text-center text-md-right">
                <img class="img-fluid" src="./img/payments.png" alt="">
            </div>
        </div>
    </div>
    <!-- Footer End -->


    <!-- Back to Top -->
    <a href="#" class="btn btn-primary back-to-top"><i class="fa fa-angle-double-up"></i></a>


    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.bundle.min.js"></script>
    <script src="lib/easing/easing.min.js"></script>
    <script src="lib/owlcarousel/owl.carousel.min.js"></script>

    <!-- Contact Javascript File -->
    <script src="mail/jqBootstrapValidation.min.js"></script>
    <script src="mail/contact.js"></script>

    <!-- Template Javascript -->
    <script src="js/main.js"></script>


    <script>
        let product_price = document.querySelectorAll('.product_price'),
            product_total = document.querySelectorAll('.product_total'),
            btn_minus = document.querySelectorAll('.btn-minus'),
            btn_plus = document.querySelectorAll('.btn-plus'),
            product_quantity = document.querySelectorAll('.product_quantity'),
            subtotal = document.querySelector('.subtotal'),
            last_total = document.querySelector('.last_total'),
            cart_form = document.querySelectorAll('.cart_form'),
            submit_cart_form = document.querySelector('.submit_cart_form'),
            cart_message = document.querySelector('.cart_message')
        let sum = 0;


        btn_minus.forEach((crr, index) => {
            let crr_ele = crr.parentElement.parentElement.querySelector('.product_quantity')
            let crr_price = parseInt(product_price[index].innerHTML);
            let crr_ele_int = parseInt(crr_ele)
            crr.addEventListener('click', () => {

                let crr_product_total = parseInt(product_total[index].value)
                let crr_ele_index = parseInt(crr_ele.value);
                if (crr_ele_index == 0) {
                    crr_ele.value = 1;
                    product_total[index].value = crr_product_total -= crr_price
                }
                console.log(crr_product_total);
                if (crr_product_total == 0) {
                    product_total[index].value = crr_price
                } else {
                    product_total[index].value = crr_product_total -= crr_price
                }
            })
            // product_total.forEach(crr => {
            //     let values = parseInt(crr.value);
            //     sum += values
            // })
        })
        btn_plus.forEach((crr, index) => {
            let crr_ele = crr.parentElement.parentElement.querySelector('.product_quantity')
            let crr_price = parseInt(product_price[index].innerHTML);
            let crr_ele_int = parseInt(crr_ele)
            let increament_price = crr_price + crr_price + crr_price + crr_price + crr_price;
            crr.addEventListener('click', () => {


                let crr_ele_index = parseInt(crr_ele.value);
                let crr_product_total = parseInt(product_total[index].value)
                if (increament_price != crr_product_total) {
                    product_total[index].value = crr_product_total += crr_price
                } else {
                    product_total[index].addEventListener('input', () => {
                        product_total[index].value = crr_product_total
                    })
                }
                if (crr_ele_index >= 5) {
                    crr_ele.value = 5;
                }
            })

        })



        setInterval(() => {
            product_total.forEach((crr) => {
                sum += +crr.value
                setInterval(() => {
                    sum = 0
                }, 50)
            })

            subtotal.innerHTML = sum
            last_total.innerHTML = +subtotal.innerHTML + 10
        }, 100)


        cart_form.forEach(crr => {
            crr.addEventListener('submit', (e) => {
                e.preventDefault()
            })

            submit_cart_form.addEventListener('click', () => {
                let xhr = new XMLHttpRequest();
                xhr.open('POST', 'order.php', true)
                xhr.onload = () => {
                    if (xhr.status == 200) {
                        let data = xhr.responseText
                        console.log(data);

                        cart_message.innerHTML = data
                    } else {
                        console.log('error');
                    }
                }
                let formData = new FormData(crr)
                xhr.send(formData)
            })

        })
    </script>
</body>

</html>