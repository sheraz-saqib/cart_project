<?php $con = mysqli_connect("localhost", "root", "", "project"); 
// require_once 'sendgrid-email/config.php';
// require 'sendgrid-email/vendor/autoload.php';

session_start();
$session_id = session_id();

?>